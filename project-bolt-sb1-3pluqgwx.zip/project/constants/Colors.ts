export const Colors = {
  pastel: {
    lavender: '#E6E6FA',
    mint: '#B5EAD7',
    peach: '#FFD8BE',
    skyBlue: '#C9E4DE',
    pink: '#FFB3BA',
    yellow: '#FFFFBA',
    lilac: '#D4A5D4',
    cream: '#FFF5E1',
  },
  dark: {
    lavender: '#B8B8DC',
    mint: '#8FC7AE',
    peach: '#E6B89C',
    skyBlue: '#9CBDB5',
    text: '#4A4A4A',
  },
  neutral: {
    white: '#FFFFFF',
    lightGray: '#F5F5F5',
    gray: '#CCCCCC',
    darkGray: '#666666',
    text: '#333333',
  },
};
