import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Modal, FlatList, Image, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'expo-router';
import { LogOut, Edit2, Users, Grid, UserPlus, X, Check } from 'lucide-react-native';

interface Post {
  id: string;
  media_url: string;
  media_type: string;
  created_at: string;
}

interface Friend {
  id: string;
  username: string;
  display_name: string;
  avatar_url?: string;
  status: string;
}

const { width } = Dimensions.get('window');
const imageSize = (width - 45) / 3;

export default function ProfileScreen() {
  const { user, profile, signOut, updateProfile } = useAuth();
  const router = useRouter();
  const [posts, setPosts] = useState<Post[]>([]);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showFriendsModal, setShowFriendsModal] = useState(false);
  const [editDisplayName, setEditDisplayName] = useState('');
  const [editBio, setEditBio] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadPosts();
    loadFriends();
    if (profile) {
      setEditDisplayName(profile.display_name);
      setEditBio(profile.bio || '');
    }
  }, [profile]);

  const loadPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('user_id', user?.id || '')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error('Error loading posts:', error);
    }
  };

  const loadFriends = async () => {
    try {
      const { data: friendshipsData } = await supabase
        .from('friendships')
        .select(`
          id,
          friend_id,
          user_id,
          status,
          profiles!friendships_friend_id_fkey (
            id,
            username,
            display_name,
            avatar_url
          )
        `)
        .or(`user_id.eq.${user?.id},friend_id.eq.${user?.id}`);

      const friendsList = (friendshipsData?.map(f => ({
        ...f.profiles,
        status: f.status,
      })) || []) as unknown as Friend[];

      setFriends(friendsList || []);
    } catch (error) {
      console.error('Error loading friends:', error);
    }
  };

  const handleSaveProfile = async () => {
    setLoading(true);
    try {
      await updateProfile({
        display_name: editDisplayName,
        bio: editBio,
      });
      setShowEditModal(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      router.replace('/(auth)/welcome');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const renderPost = ({ item }: { item: Post }) => (
    <TouchableOpacity style={styles.gridItem}>
      <Image source={{ uri: item.media_url }} style={styles.gridImage} />
    </TouchableOpacity>
  );

  const renderFriend = ({ item }: { item: Friend }) => (
    <View style={styles.friendItem}>
      <View style={styles.avatar}>
        <Text style={styles.avatarText}>
          {item.display_name.charAt(0).toUpperCase()}
        </Text>
      </View>
      <View style={styles.friendInfo}>
        <Text style={styles.friendName}>{item.display_name}</Text>
        <Text style={styles.friendUsername}>@{item.username}</Text>
      </View>
      {item.status === 'pending' && (
        <View style={styles.pendingBadge}>
          <Text style={styles.pendingText}>En attente</Text>
        </View>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[Colors.pastel.lavender, Colors.pastel.mint]}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <View style={styles.profileHeader}>
            <View style={styles.avatarLarge}>
              <Text style={styles.avatarLargeText}>
                {profile?.display_name.charAt(0).toUpperCase()}
              </Text>
            </View>

            <View style={styles.stats}>
              <View style={styles.statItem}>
                <Text style={styles.statNumber}>{posts.length}</Text>
                <Text style={styles.statLabel}>Posts</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statNumber}>
                  {friends.filter(f => f.status === 'accepted').length}
                </Text>
                <Text style={styles.statLabel}>Amis</Text>
              </View>
            </View>
          </View>

          <Text style={styles.displayName}>{profile?.display_name}</Text>
          <Text style={styles.username}>@{profile?.username}</Text>
          {profile?.bio ? (
            <Text style={styles.bio}>{profile.bio}</Text>
          ) : null}

          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={styles.editButton}
              onPress={() => setShowEditModal(true)}
            >
              <Edit2 size={16} color={Colors.dark.lavender} />
              <Text style={styles.editButtonText}>Éditer</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.friendsButton}
              onPress={() => setShowFriendsModal(true)}
            >
              <Users size={16} color={Colors.dark.lavender} />
              <Text style={styles.editButtonText}>Amis</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.logoutButton} onPress={handleSignOut}>
              <LogOut size={16} color={Colors.neutral.white} />
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>

      <ScrollView style={styles.content}>
        <View style={styles.postsHeader}>
          <Grid size={20} color={Colors.neutral.text} />
          <Text style={styles.postsTitle}>Mes posts</Text>
        </View>

        {posts.length > 0 ? (
          <FlatList
            data={posts}
            renderItem={renderPost}
            keyExtractor={(item) => item.id}
            numColumns={3}
            scrollEnabled={false}
            columnWrapperStyle={styles.gridRow}
          />
        ) : (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Aucun post pour le moment</Text>
          </View>
        )}
      </ScrollView>

      <Modal
        visible={showEditModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowEditModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Éditer le profil</Text>
              <TouchableOpacity onPress={() => setShowEditModal(false)}>
                <X size={24} color={Colors.neutral.text} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.modalBody}>
              <Text style={styles.label}>Nom d'affichage</Text>
              <TextInput
                style={styles.input}
                value={editDisplayName}
                onChangeText={setEditDisplayName}
                placeholder="Ton nom"
              />

              <Text style={styles.label}>Bio</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={editBio}
                onChangeText={setEditBio}
                placeholder="Parle-nous de toi..."
                multiline
                maxLength={150}
              />

              <TouchableOpacity
                style={[styles.saveButton, loading && styles.saveButtonDisabled]}
                onPress={handleSaveProfile}
                disabled={loading}
              >
                <Check size={20} color={Colors.neutral.white} />
                <Text style={styles.saveButtonText}>
                  {loading ? 'Enregistrement...' : 'Enregistrer'}
                </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showFriendsModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowFriendsModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Mes amis</Text>
              <TouchableOpacity onPress={() => setShowFriendsModal(false)}>
                <X size={24} color={Colors.neutral.text} />
              </TouchableOpacity>
            </View>

            <FlatList
              data={friends}
              renderItem={renderFriend}
              keyExtractor={(item) => item.id}
              contentContainerStyle={styles.friendsList}
              ListEmptyComponent={
                <Text style={styles.emptyText}>Aucun ami pour le moment</Text>
              }
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral.white,
  },
  header: {
    paddingTop: 50,
    paddingBottom: 25,
  },
  headerContent: {
    paddingHorizontal: 20,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  avatarLarge: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.neutral.white,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 20,
  },
  avatarLargeText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: Colors.dark.lavender,
  },
  stats: {
    flexDirection: 'row',
    gap: 30,
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.neutral.white,
  },
  statLabel: {
    fontSize: 12,
    color: Colors.neutral.white,
    opacity: 0.9,
  },
  displayName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.neutral.white,
    marginBottom: 4,
  },
  username: {
    fontSize: 16,
    color: Colors.neutral.white,
    opacity: 0.9,
    marginBottom: 10,
  },
  bio: {
    fontSize: 14,
    color: Colors.neutral.white,
    lineHeight: 20,
    marginBottom: 15,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  editButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.neutral.white,
    paddingVertical: 10,
    borderRadius: 20,
  },
  friendsButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.neutral.white,
    paddingVertical: 10,
    borderRadius: 20,
  },
  editButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.dark.lavender,
  },
  logoutButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 107, 107, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    backgroundColor: Colors.neutral.lightGray,
  },
  postsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 15,
    backgroundColor: Colors.neutral.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral.lightGray,
  },
  postsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.neutral.text,
  },
  gridRow: {
    gap: 2,
    paddingHorizontal: 1,
  },
  gridItem: {
    width: imageSize,
    height: imageSize,
    margin: 1,
  },
  gridImage: {
    width: '100%',
    height: '100%',
  },
  emptyContainer: {
    padding: 40,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
    color: Colors.neutral.gray,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: Colors.neutral.white,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    paddingTop: 20,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral.lightGray,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: Colors.neutral.text,
  },
  modalBody: {
    padding: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.neutral.text,
    marginBottom: 8,
    marginTop: 15,
  },
  input: {
    backgroundColor: Colors.neutral.lightGray,
    borderRadius: 12,
    padding: 15,
    fontSize: 16,
    color: Colors.neutral.text,
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: Colors.dark.lavender,
    paddingVertical: 16,
    borderRadius: 25,
    marginTop: 25,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.neutral.white,
  },
  friendsList: {
    padding: 20,
  },
  friendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral.lightGray,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: Colors.pastel.lavender,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.neutral.white,
  },
  friendInfo: {
    flex: 1,
  },
  friendName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.neutral.text,
  },
  friendUsername: {
    fontSize: 12,
    color: Colors.neutral.gray,
  },
  pendingBadge: {
    backgroundColor: Colors.pastel.yellow,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
  },
  pendingText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.dark.text,
  },
});
