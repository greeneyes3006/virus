import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
import Constants from 'expo-constants';

const supabaseUrl = Constants.expoConfig?.extra?.EXPO_PUBLIC_SUPABASE_URL || process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://mloxonkbyctpzibuxyta.supabase.co';
const supabaseAnonKey = Constants.expoConfig?.extra?.EXPO_PUBLIC_SUPABASE_ANON_KEY || process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1sb3hvbmtieWN0cHppYnV4eXRhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjExNDMwNzYsImV4cCI6MjA3NjcxOTA3Nn0.76DA5t3ZEPpRujFrrofxrXIIvdIfLdGhN_jeTbHaMCU';

console.log('[Supabase] URL:', supabaseUrl);
console.log('[Supabase] Key:', supabaseAnonKey ? 'Present' : 'Missing');

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});
