import { useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Modal, ScrollView, Alert } from 'react-native';
import { CameraView, CameraType, useCameraPermissions } from 'expo-camera';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { FlipHorizontal, X, Check, Sparkles } from 'lucide-react-native';

const FILTERS = [
  { name: 'none', label: 'Original', color: Colors.neutral.white },
  { name: 'pastel', label: 'Pastel', color: Colors.pastel.lavender },
  { name: 'warm', label: 'Chaud', color: Colors.pastel.peach },
  { name: 'cool', label: 'Frais', color: Colors.pastel.mint },
  { name: 'dreamy', label: 'Rêveur', color: Colors.pastel.pink },
];

export default function CameraScreen() {
  const { user } = useAuth();
  const [facing, setFacing] = useState<CameraType>('back');
  const [permission, requestPermission] = useCameraPermissions();
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [selectedFilter, setSelectedFilter] = useState('none');
  const [caption, setCaption] = useState('');
  const [uploading, setUploading] = useState(false);
  const cameraRef = useRef<any>(null);

  if (!permission) {
    return (
      <View style={styles.container}>
        <Text style={styles.message}>Chargement...</Text>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <LinearGradient
          colors={[Colors.pastel.lavender, Colors.pastel.mint]}
          style={styles.permissionContainer}
        >
          <Sparkles size={60} color={Colors.neutral.white} />
          <Text style={styles.permissionTitle}>Accès caméra requis</Text>
          <Text style={styles.permissionText}>
            Pixi a besoin d'accéder à ta caméra pour créer des souvenirs magiques
          </Text>
          <TouchableOpacity style={styles.permissionButton} onPress={requestPermission}>
            <Text style={styles.permissionButtonText}>Autoriser la caméra</Text>
          </TouchableOpacity>
        </LinearGradient>
      </View>
    );
  }

  const toggleCameraFacing = () => {
    setFacing(current => (current === 'back' ? 'front' : 'back'));
  };

  const takePicture = async () => {
    if (cameraRef.current) {
      try {
        const photo = await cameraRef.current.takePictureAsync({
          quality: 0.8,
        });
        setCapturedPhoto(photo.uri);
      } catch (error) {
        console.error('Error taking picture:', error);
      }
    }
  };

  const uploadPost = async () => {
    if (!capturedPhoto || !user) return;

    setUploading(true);

    try {
      const fileName = `${user.id}_${Date.now()}.jpg`;
      const formData = new FormData();

      formData.append('file', {
        uri: capturedPhoto,
        type: 'image/jpeg',
        name: fileName,
      } as any);

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('posts')
        .upload(fileName, formData);

      if (uploadError) throw uploadError;

      const { data: publicUrlData } = supabase.storage
        .from('posts')
        .getPublicUrl(fileName);

      const { error: insertError } = await supabase.from('posts').insert({
        user_id: user.id,
        media_url: publicUrlData.publicUrl,
        media_type: 'photo',
        caption: caption,
        filter_applied: selectedFilter,
      });

      if (insertError) throw insertError;

      Alert.alert('Succès', 'Ton post a été publié !');
      setCapturedPhoto(null);
      setCaption('');
      setSelectedFilter('none');
    } catch (error: any) {
      Alert.alert('Erreur', error.message || 'Impossible de publier le post');
      console.error('Error uploading post:', error);
    } finally {
      setUploading(false);
    }
  };

  if (capturedPhoto) {
    return (
      <View style={styles.container}>
        <LinearGradient
          colors={[Colors.pastel.skyBlue, Colors.pastel.peach]}
          style={styles.header}
        >
          <Text style={styles.headerTitle}>Édition</Text>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setCapturedPhoto(null)}
          >
            <X size={24} color={Colors.neutral.white} />
          </TouchableOpacity>
        </LinearGradient>

        <ScrollView style={styles.editContainer}>
          <View style={styles.filterContainer}>
            <Text style={styles.sectionTitle}>Filtres</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={styles.filterList}>
                {FILTERS.map((filter) => (
                  <TouchableOpacity
                    key={filter.name}
                    style={[
                      styles.filterButton,
                      { backgroundColor: filter.color },
                      selectedFilter === filter.name && styles.filterButtonActive,
                    ]}
                    onPress={() => setSelectedFilter(filter.name)}
                  >
                    <Text style={styles.filterLabel}>{filter.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>

          <View style={styles.captionContainer}>
            <Text style={styles.sectionTitle}>Légende</Text>
            <TextInput
              style={styles.captionInput}
              placeholder="Ajoute une légende à ton post..."
              placeholderTextColor={Colors.neutral.gray}
              value={caption}
              onChangeText={setCaption}
              multiline
              maxLength={200}
            />
          </View>

          <TouchableOpacity
            style={[styles.publishButton, uploading && styles.publishButtonDisabled]}
            onPress={uploadPost}
            disabled={uploading}
          >
            <Check size={20} color={Colors.neutral.white} />
            <Text style={styles.publishButtonText}>
              {uploading ? 'Publication...' : 'Publier'}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <CameraView style={styles.camera} facing={facing} ref={cameraRef}>
        <LinearGradient
          colors={['rgba(0,0,0,0.3)', 'transparent']}
          style={styles.topBar}
        >
          <Text style={styles.cameraTitle}>Pixi Caméra</Text>
        </LinearGradient>

        <View style={styles.cameraControls}>
          <TouchableOpacity style={styles.controlButton} onPress={toggleCameraFacing}>
            <FlipHorizontal size={28} color={Colors.neutral.white} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.captureButton} onPress={takePicture}>
            <View style={styles.captureButtonInner} />
          </TouchableOpacity>

          <View style={styles.controlButton} />
        </View>
      </CameraView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral.white,
  },
  camera: {
    flex: 1,
  },
  permissionContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 30,
  },
  permissionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.neutral.white,
    marginTop: 20,
    marginBottom: 10,
    textAlign: 'center',
  },
  permissionText: {
    fontSize: 16,
    color: Colors.neutral.white,
    textAlign: 'center',
    marginBottom: 30,
    opacity: 0.9,
  },
  permissionButton: {
    backgroundColor: Colors.neutral.white,
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 25,
  },
  permissionButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.dark.text,
  },
  message: {
    fontSize: 16,
    color: Colors.neutral.gray,
  },
  topBar: {
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  cameraTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.neutral.white,
  },
  cameraControls: {
    position: 'absolute',
    bottom: 40,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingHorizontal: 30,
  },
  controlButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  captureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.neutral.white,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 4,
    borderColor: 'rgba(255, 255, 255, 0.5)',
  },
  captureButtonInner: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: Colors.neutral.white,
  },
  header: {
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.neutral.white,
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  editContainer: {
    flex: 1,
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.neutral.text,
    marginBottom: 12,
  },
  filterContainer: {
    marginBottom: 25,
  },
  filterList: {
    flexDirection: 'row',
    gap: 10,
  },
  filterButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  filterButtonActive: {
    borderColor: Colors.dark.lavender,
  },
  filterLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.neutral.text,
  },
  captionContainer: {
    marginBottom: 25,
  },
  captionInput: {
    backgroundColor: Colors.neutral.lightGray,
    borderRadius: 15,
    padding: 15,
    fontSize: 16,
    color: Colors.neutral.text,
    minHeight: 100,
    textAlignVertical: 'top',
  },
  publishButton: {
    backgroundColor: Colors.dark.lavender,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 16,
    borderRadius: 25,
  },
  publishButtonDisabled: {
    opacity: 0.6,
  },
  publishButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.neutral.white,
  },
});
