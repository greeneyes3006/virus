import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, RefreshControl, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Eye, Heart } from 'lucide-react-native';

interface Post {
  id: string;
  user_id: string;
  media_url: string;
  media_type: string;
  caption: string;
  filter_applied: string;
  created_at: string;
  profiles: {
    username: string;
    display_name: string;
    avatar_url?: string;
  };
  view_count?: number;
  views_left?: number;
}

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    try {
      const { data: friendships } = await supabase
        .from('friendships')
        .select('friend_id, user_id')
        .or(`user_id.eq.${user?.id},friend_id.eq.${user?.id}`)
        .eq('status', 'accepted');

      const friendIds = friendships?.map(f =>
        f.user_id === user?.id ? f.friend_id : f.user_id
      ) || [];

      const { data: postsData, error } = await supabase
        .from('posts')
        .select(`
          *,
          profiles:user_id (
            username,
            display_name,
            avatar_url
          )
        `)
        .in('user_id', [...friendIds, user?.id || ''])
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      const postsWithViews = await Promise.all(
        postsData?.map(async (post) => {
          const { data: viewData } = await supabase
            .from('post_views')
            .select('view_count')
            .eq('post_id', post.id)
            .eq('user_id', user?.id || '')
            .maybeSingle();

          const viewCount = viewData?.view_count || 0;
          return {
            ...post,
            view_count: viewCount,
            views_left: 3 - viewCount,
          };
        }) || []
      );

      setPosts(postsWithViews);
    } catch (error) {
      console.error('Error loading posts:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleViewPost = async (postId: string) => {
    try {
      const { data: existingView } = await supabase
        .from('post_views')
        .select('*')
        .eq('post_id', postId)
        .eq('user_id', user?.id || '')
        .maybeSingle();

      if (existingView) {
        if (existingView.view_count >= 3) {
          return;
        }

        await supabase
          .from('post_views')
          .update({
            view_count: existingView.view_count + 1,
            last_viewed_at: new Date().toISOString(),
          })
          .eq('id', existingView.id);
      } else {
        await supabase.from('post_views').insert({
          post_id: postId,
          user_id: user?.id || '',
          view_count: 1,
        });
      }

      loadPosts();
    } catch (error) {
      console.error('Error recording view:', error);
    }
  };

  const renderPost = ({ item }: { item: Post }) => {
    const isBlurred = (item.view_count || 0) >= 3;

    return (
      <View style={styles.postCard}>
        <View style={styles.postHeader}>
          <View style={styles.userInfo}>
            <View style={styles.avatar}>
              {item.profiles.avatar_url ? (
                <Image source={{ uri: item.profiles.avatar_url }} style={styles.avatarImage} />
              ) : (
                <Text style={styles.avatarText}>
                  {item.profiles.display_name.charAt(0).toUpperCase()}
                </Text>
              )}
            </View>
            <View>
              <Text style={styles.displayName}>{item.profiles.display_name}</Text>
              <Text style={styles.username}>@{item.profiles.username}</Text>
            </View>
          </View>
          {item.views_left !== undefined && (
            <View style={styles.viewBadge}>
              <Eye size={14} color={Colors.neutral.white} />
              <Text style={styles.viewText}>{item.views_left}</Text>
            </View>
          )}
        </View>

        <TouchableOpacity
          onPress={() => !isBlurred && handleViewPost(item.id)}
          disabled={isBlurred}
          activeOpacity={0.9}
        >
          <View style={styles.mediaContainer}>
            {item.media_type === 'photo' && (
              <Image
                source={{ uri: item.media_url }}
                style={[styles.media, isBlurred && styles.blurred]}
                blurRadius={isBlurred ? 20 : 0}
              />
            )}
            {isBlurred && (
              <View style={styles.blurOverlay}>
                <Eye size={40} color={Colors.neutral.white} />
                <Text style={styles.blurText}>Plus de vues disponibles</Text>
              </View>
            )}
          </View>
        </TouchableOpacity>

        {item.caption ? (
          <Text style={styles.caption}>{item.caption}</Text>
        ) : null}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[Colors.pastel.lavender, Colors.pastel.mint]}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>Pixi</Text>
      </LinearGradient>

      <FlatList
        data={posts}
        renderItem={renderPost}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              loadPosts();
            }}
            tintColor={Colors.dark.lavender}
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>
              {loading ? 'Chargement...' : 'Aucun contenu pour le moment'}
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral.lightGray,
  },
  header: {
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.neutral.white,
  },
  list: {
    padding: 15,
  },
  postCard: {
    backgroundColor: Colors.neutral.white,
    borderRadius: 20,
    marginBottom: 15,
    overflow: 'hidden',
  },
  postHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.pastel.lavender,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  avatarText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.neutral.white,
  },
  displayName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.neutral.text,
  },
  username: {
    fontSize: 12,
    color: Colors.neutral.gray,
  },
  viewBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: Colors.dark.lavender,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 15,
  },
  viewText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.neutral.white,
  },
  mediaContainer: {
    position: 'relative',
    width: '100%',
    height: width - 30,
  },
  media: {
    width: '100%',
    height: '100%',
  },
  blurred: {
    opacity: 0.3,
  },
  blurOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
  },
  blurText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.neutral.white,
    marginTop: 10,
  },
  caption: {
    padding: 15,
    fontSize: 14,
    color: Colors.neutral.text,
    lineHeight: 20,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 50,
  },
  emptyText: {
    fontSize: 16,
    color: Colors.neutral.gray,
  },
});
