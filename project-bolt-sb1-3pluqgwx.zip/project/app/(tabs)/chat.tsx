import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, TextInput, Modal } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { MessageCircle, Plus, Send, X } from 'lucide-react-native';
import { useRouter } from 'expo-router';

interface Conversation {
  id: string;
  updated_at: string;
  participants: Array<{
    user_id: string;
    profiles: {
      username: string;
      display_name: string;
      avatar_url?: string;
    };
  }>;
  last_message?: {
    content: string;
    created_at: string;
  };
}

interface Friend {
  id: string;
  username: string;
  display_name: string;
  avatar_url?: string;
}

export default function ChatScreen() {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewChatModal, setShowNewChatModal] = useState(false);

  useEffect(() => {
    loadConversations();
    loadFriends();
  }, []);

  const loadConversations = async () => {
    try {
      const { data: participantData } = await supabase
        .from('conversation_participants')
        .select('conversation_id')
        .eq('user_id', user?.id || '');

      const conversationIds = participantData?.map(p => p.conversation_id) || [];

      if (conversationIds.length === 0) {
        setLoading(false);
        return;
      }

      const { data: conversationsData, error } = await supabase
        .from('conversations')
        .select(`
          id,
          updated_at,
          conversation_participants!inner (
            user_id,
            profiles:user_id (
              username,
              display_name,
              avatar_url
            )
          )
        `)
        .in('id', conversationIds)
        .order('updated_at', { ascending: false });

      if (error) throw error;

      const conversationsWithMessages = await Promise.all(
        conversationsData?.map(async (conv: any) => {
          const { data: lastMessage } = await supabase
            .from('messages')
            .select('content, created_at')
            .eq('conversation_id', conv.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          return {
            ...conv,
            participants: conv.conversation_participants.filter(
              (p: any) => p.user_id !== user?.id
            ),
            last_message: lastMessage,
          };
        }) || []
      );

      setConversations(conversationsWithMessages);
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadFriends = async () => {
    try {
      const { data: friendships } = await supabase
        .from('friendships')
        .select(`
          friend_id,
          user_id,
          profiles!friendships_friend_id_fkey (
            id,
            username,
            display_name,
            avatar_url
          )
        `)
        .or(`user_id.eq.${user?.id},friend_id.eq.${user?.id}`)
        .eq('status', 'accepted');

      const friendsList = (friendships?.map(f => {
        const friendProfile = f.user_id === user?.id
          ? f.profiles
          : f.profiles;
        return friendProfile;
      }).filter(Boolean) || []) as unknown as Friend[];

      setFriends(friendsList);
    } catch (error) {
      console.error('Error loading friends:', error);
    }
  };

  const createConversation = async (friendId: string) => {
    try {
      const { data: existingConv } = await supabase
        .from('conversation_participants')
        .select('conversation_id')
        .eq('user_id', user?.id || '')
        .then(async ({ data }) => {
          if (!data) return { data: null };

          const convIds = data.map(d => d.conversation_id);
          return await supabase
            .from('conversation_participants')
            .select('conversation_id')
            .eq('user_id', friendId)
            .in('conversation_id', convIds)
            .maybeSingle();
        });

      if (existingConv?.conversation_id) {
        setShowNewChatModal(false);
        return;
      }

      const { data: newConv, error: convError } = await supabase
        .from('conversations')
        .insert({})
        .select()
        .single();

      if (convError) throw convError;

      await supabase.from('conversation_participants').insert([
        { conversation_id: newConv.id, user_id: user?.id || '' },
        { conversation_id: newConv.id, user_id: friendId },
      ]);

      setShowNewChatModal(false);
      loadConversations();
    } catch (error) {
      console.error('Error creating conversation:', error);
    }
  };

  const renderConversation = ({ item }: { item: Conversation }) => {
    const otherUser = item.participants[0]?.profiles;
    if (!otherUser) return null;

    return (
      <TouchableOpacity style={styles.conversationCard}>
        <View style={styles.avatar}>
          {otherUser.avatar_url ? null : (
            <Text style={styles.avatarText}>
              {otherUser.display_name.charAt(0).toUpperCase()}
            </Text>
          )}
        </View>

        <View style={styles.conversationContent}>
          <View style={styles.conversationHeader}>
            <Text style={styles.displayName}>{otherUser.display_name}</Text>
            <Text style={styles.timestamp}>
              {new Date(item.updated_at).toLocaleDateString('fr-FR', {
                day: 'numeric',
                month: 'short',
              })}
            </Text>
          </View>
          <Text style={styles.lastMessage} numberOfLines={1}>
            {item.last_message?.content || 'Nouvelle conversation'}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  const renderFriend = ({ item }: { item: Friend }) => (
    <TouchableOpacity
      style={styles.friendCard}
      onPress={() => createConversation(item.id)}
    >
      <View style={styles.avatar}>
        <Text style={styles.avatarText}>
          {item.display_name.charAt(0).toUpperCase()}
        </Text>
      </View>
      <View>
        <Text style={styles.displayName}>{item.display_name}</Text>
        <Text style={styles.username}>@{item.username}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[Colors.pastel.lavender, Colors.pastel.mint]}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>Messages</Text>
        <TouchableOpacity
          style={styles.newChatButton}
          onPress={() => setShowNewChatModal(true)}
        >
          <Plus size={24} color={Colors.neutral.white} />
        </TouchableOpacity>
      </LinearGradient>

      <FlatList
        data={conversations}
        renderItem={renderConversation}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <MessageCircle size={60} color={Colors.neutral.gray} />
            <Text style={styles.emptyText}>
              {loading ? 'Chargement...' : 'Aucune conversation'}
            </Text>
            <Text style={styles.emptySubtext}>
              Appuie sur + pour commencer une conversation
            </Text>
          </View>
        }
      />

      <Modal
        visible={showNewChatModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowNewChatModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Nouvelle conversation</Text>
              <TouchableOpacity onPress={() => setShowNewChatModal(false)}>
                <X size={24} color={Colors.neutral.text} />
              </TouchableOpacity>
            </View>

            <FlatList
              data={friends}
              renderItem={renderFriend}
              keyExtractor={(item) => item.id}
              contentContainerStyle={styles.friendsList}
              ListEmptyComponent={
                <Text style={styles.emptyText}>Aucun ami pour le moment</Text>
              }
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral.lightGray,
  },
  header: {
    paddingTop: 50,
    paddingBottom: 15,
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.neutral.white,
  },
  newChatButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  list: {
    padding: 15,
  },
  conversationCard: {
    flexDirection: 'row',
    backgroundColor: Colors.neutral.white,
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
    alignItems: 'center',
    gap: 12,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: Colors.pastel.lavender,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.neutral.white,
  },
  conversationContent: {
    flex: 1,
  },
  conversationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  displayName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.neutral.text,
  },
  username: {
    fontSize: 12,
    color: Colors.neutral.gray,
  },
  timestamp: {
    fontSize: 12,
    color: Colors.neutral.gray,
  },
  lastMessage: {
    fontSize: 14,
    color: Colors.neutral.gray,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 80,
  },
  emptyText: {
    fontSize: 16,
    color: Colors.neutral.gray,
    marginTop: 15,
  },
  emptySubtext: {
    fontSize: 14,
    color: Colors.neutral.gray,
    marginTop: 5,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: Colors.neutral.white,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    paddingTop: 20,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral.lightGray,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: Colors.neutral.text,
  },
  friendsList: {
    padding: 20,
  },
  friendCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral.lightGray,
  },
});
